<?php

namespace App\Models;

use CodeIgniter\Model;

class AnggotaPklModel extends Model
{
    protected $table            = 'anggota_pkl';
    protected $primaryKey       = 'id_anggota';
    protected $allowedFields    = [
        'mahasiswa_id',
        'pkl_id',
        'ketua'
    ];
}
