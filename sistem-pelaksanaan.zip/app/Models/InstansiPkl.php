<?php

namespace App\Models;

use CodeIgniter\Model;

class InstansiPkl extends Model
{
    protected $table            = 'instansi_pkl';
    protected $primaryKey       = 'id_instansi_pkl';
    protected $allowedFields    = [
        'nama_perusahaan', 
        'alamat', 
        'pembimbing_lapangan', 
        'no_pembimbing_lapangan',
        'kelompok'
    ];
}
