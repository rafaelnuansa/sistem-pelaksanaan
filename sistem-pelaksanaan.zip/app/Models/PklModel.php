<?php

namespace App\Models;

use CodeIgniter\Model;

class PklModel extends Model
{
    protected $table            = 'pkl';
    protected $primaryKey       = 'id';
    protected $allowedFields    = [
        'nama_kelompok',
        'tgl_mulai',
        'tgl_selesai',
        'pembimbing_lapangan',
        'nama_institusi',
        'no_hp_pl',
        'alamat',
        'tahun_akademik',
        'dosen_id',
        'prodi_id'
    ];
}
