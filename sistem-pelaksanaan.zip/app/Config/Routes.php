<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (is_file(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
$routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Home::login');
$routes->get('/logout', 'LoginController::logout');
$routes->post('/login', 'LoginController::auth');

$routes->get('/test', 'CetakLaporan::index');

/*
* Menu Mahasiswa
* 
*/
$routes->group('mahasiswa', ['filter' => 'auth2'], function ($routes) {
    $routes->get('', 'KelompokPklMahasiswa::index');
    $routes->post('', 'KelompokPklMahasiswa::update_instansi');

    // Jurnal Pelaksanaan
    $routes->get('pkl/jurnal/pelaksanaan', 'JurnalPklMahasiswa::pelaksanaan');
    $routes->post('pkl/jurnal/1', 'JurnalPklMahasiswa::simpan');

    $routes->get('pkl/jurnal/2/approve/(:segment)', 'JurnalPklMahasiswa::approve/$1');

    // Jurnal bimbingan
    $routes->get('pkl/jurnal/bimbingan', 'JurnalPklMahasiswa::bimbingan');
    $routes->post('pkl/jurnal/bimbingan', 'JurnalPklMahasiswa::simpan_judul');
    $routes->post('pkl/jurnal/2', 'JurnalPklMahasiswa::simpan2');
    $routes->get('pkl/jurnal/1/approve/(:segment)', 'JurnalPklMahasiswa::approve2/$1');
    $routes->get('pkl/jurnal/1/unapprove/(:segment)', 'JurnalPklMahasiswa::unapprove2/$1');

    // Formulir penilaian
    $routes->get('pkl/formulir', 'KelompokPklMahasiswa::formulir');
    $routes->get('pkl/formulir/log-harian', 'JurnalPklMahasiswa::log_harian');

    // Daftar sidang
    $routes->get('pkl/daftar', 'UjianPkl::index');
    $routes->post('pkl/daftar', 'UjianPkl::simpan');

    $routes->get('pkl/jadwal', 'JadwalPkl::mahasiswa');

    $routes->get('upload-berkas', 'UploadBerkas::index');
    $routes->post('upload-berkas', 'UploadBerkas::simpan');
    $routes->post('upload-berkas/delete', 'UploadBerkas::delete');
});

/*
* Menu Dosen
* 
*/
$routes->group('dosen', ['filter' => 'auth3'], function ($routes) {
    $routes->get('', 'HomeDosen::index');
    $routes->get('pkl/approve', 'HomeDosen::approve_bimbingan');
    $routes->get('pkl/jurnal/detail/(:segment)', 'HomeDosen::bimbingan_detail/$1');
    $routes->get('pkl/detail', 'HomeDosen::detail');
    $routes->get('pkl/jadwal', 'HomeDosen::jadwal_pkl');

    $routes->get('pkl/penilaian/1', 'HomeDosen::penilaian');
    $routes->post('pkl/penilaian/cetak', 'HomeDosen::cetak');
    $routes->post('pkl/revisi/cetak', 'HomeDosen::cetak_revisi');
    $routes->get('pkl/penilaian/2', 'HomeDosen::penilaian2');
});

/*
* Menu Admin/Staff
* 
*/
$routes->group('', ['filter' => 'auth'], function ($routes) {
    $routes->get('/dashboard', 'Home::index');

    /*
    * Modul PKL
     */

    // Kelompok Pkl
    $routes->get('/pkl/kelompok', 'KelompokPkl::index');
    $routes->post('/pkl/kelompok', 'KelompokPkl::simpan');
    $routes->get('/pkl/kelompok/tambah-anggota', 'KelompokPkl::simpan_anggota');
    $routes->get('/pkl/kelompok/edit/status', 'KelompokPkl::edit_status');
    $routes->get('/pkl/kelompok/edit/(:segment)', 'KelompokPkl::edit/$1');
    $routes->post('/pkl/kelompok/update_data', 'KelompokPkl::update_data');
    $routes->get('/pkl/kelompok/edit_kelompok/(:segment)', 'KelompokPkl::edit_kelompok/$1');
    $routes->post('/pkl/kelompok/update-anggota/(:segment)', 'KelompokPkl::update_kelompok/$1');
    $routes->get('/pkl/kelompok/detail/(:segment)', 'KelompokPkl::detail_kelompok/$1');
    $routes->post('/pkl/kelompok/detail/(:segment)', 'KelompokPkl::simpan_informasi_pkl/$1');
    $routes->get('/pkl/kelompok/show', 'KelompokPkl::show');
    $routes->get('/pkl/kelompok/detail', 'KelompokPkl::detail');
    $routes->post('/pkl/kelompok/update', 'KelompokPkl::update');
    $routes->post('/pkl/kelompok/delete', 'KelompokPkl::delete');
    $routes->post('/pkl/kelompok/anggota/delete', 'KelompokPkl::delete_anggota');

    // Jurnal Pelaksanaan
    $routes->get('/pkl/jurnal/pelaksanaan', 'JurnalPkl::pelaksanaan');
    $routes->get('/pkl/jurnal/pelaksanaan/detail/(:segment)', 'JurnalPkl::pelaksanaan_detail/$1');
    // $routes->post('/pkl/jurnal/1', 'JurnalPkl::simpan');
    // $routes->post('/pkl/jurnal/1/delete', 'JurnalPkl::delete');

    // Jurnal bimbingan
    $routes->get('/pkl/jurnal/bimbingan', 'JurnalPkl::bimbingan');
    $routes->get('/pkl/jurnal/bimbingan/detail/(:segment)', 'JurnalPkl::bimbingan_detail/$1');

    // Jadwal sidang
    $routes->get('/pkl/jadwal', 'JadwalPkl::index');
    $routes->post('/pkl/jadwal/simpan', 'JadwalPkl::simpan');
    $routes->get('/pkl/jadwal/detail', 'JadwalPkl::show');
    $routes->get('pkl/jadwal/update_status/(:num)/(:num)', 'JadwalPkl::update_status/$1/$2');


    // Cetak laporan
    $routes->get('/cetak-laporan', 'CetakLaporan::index');
    $routes->get('/laporan/1', 'CetakLaporan::cetak_pkl');
    $routes->get('/laporan/2', 'CetakLaporan::cetak_jurnal1');
    $routes->get('/laporan/3', 'CetakLaporan::cetak_jurnal2');
    $routes->get('/laporan/4', 'CetakLaporan::cetak_jadwal_pkl');
    $routes->get('/laporan/5', 'CetakLaporan::cetak_dospem');

    // Dosen pembimbing
    $routes->get('/dosen_pembimbing', 'DosenPembimbing::index');
    $routes->post('/dosen_pembimbing/simpan', 'DosenPembimbing::simpan');
    $routes->post('/dosen_pembimbing/delete', 'DosenPembimbing::delete');

    // Daftar Akun
    $routes->get('/akun', 'DaftarAkun::index');
    $routes->post('/akun/simpan', 'DaftarAkun::simpan');
    $routes->get('/akun/show', 'DaftarAkun::show');
    $routes->post('/akun/update', 'DaftarAkun::update');
    $routes->post('/akun/delete', 'DaftarAkun::delete');

    // Tempat Sidang

    $routes->get('/tempat', 'TempatController::index');
    $routes->get('/tempat/create', 'TempatController::create');
    $routes->post('/tempat', 'TempatController::store');
    $routes->get('/tempat/edit/(:num)', 'TempatController::edit/$1');
    $routes->post('/tempat/update/(:num)', 'TempatController::update/$1');
    $routes->get('/tempat/delete/(:num)', 'TempatController::delete/$1');
});


/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
