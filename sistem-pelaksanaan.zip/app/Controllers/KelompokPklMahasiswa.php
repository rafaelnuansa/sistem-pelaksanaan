<?php

namespace App\Controllers;

use App\Models\{
    KelompokPklModel, 
    AnggotaPklModel,
    InstansiPkl, 
    PklModel, 
    Mahasiswa
};
use App\Controllers\BaseController;

class KelompokPklMahasiswa extends BaseController
{
    public function __construct()
    {
        $this->kelompok_model = new KelompokPklModel();
        $this->instansi_model = new InstansiPkl();
        $this->pkl_model = new PklModel();
        $this->mahasiswa_model = new Mahasiswa();
        $this->anggota_pkl_model = new AnggotaPklModel();
        $this->db = \Config\Database::connect();
    }

    public function index()
    {
        $akun = $this->anggota_pkl_model
            ->where('mahasiswa_id', session()->get('id'))
            ->where('pkl_id', session()->get('kelompok'))
            ->first();
        $rows = $this->db->table('anggota_pkl')
            ->where('pkl_id', session()->get('kelompok'))
            ->join('pkl', 'anggota_pkl.pkl_id = pkl.id')
            ->join('mahasiswa', 'anggota_pkl.mahasiswa_id = mahasiswa.id_mahasiswa')
            ->get()
            ->getResultArray();
        $instansi = $this->pkl_model->find(session()->get('kelompok'));
        
        // return d($instansi);

        $data = [
            'title' => 'Kelompok PKL',
            'data' => $rows,
            'instansi' => $instansi,
            'akun' => $akun,
        ];

        // return d($data);

        return view('mahasiswa/pkl/index', $data);
    }

    public function formulir()
    {
        return view('mahasiswa/pkl/formulir', ['title' => 'Formulir Penilaian']);
    }

    public function update_instansi()
    {
        $data = [
            'nama_institusi' => $this->request->getVar('nama_institusi'), 
            'alamat' => $this->request->getVar('alamat'), 
            'pembimbing_lapangan' => $this->request->getVar('pembimbing_lapangan'), 
            'no_hp_pl' => $this->request->getVar('no_hp_pl')
        ];

        $data['id'] = session()->get('kelompok');

        $this->pkl_model->save($data);

        session()->setFlashdata('success', 'Data berhasil disimpan!');

        return redirect()->to('/mahasiswa');
    }
}
