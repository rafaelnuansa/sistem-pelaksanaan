<?php

namespace App\Controllers;

use App\Models\{
    DosenPembimbingModel,
    KelompokPklModel,
    KeteranganKelompokPkl,
    JurusanModel,
    InstansiPkl,
    User,
    Mahasiswa,
    PklModel,
    AnggotaPklModel,
    Dosen
};
use App\Controllers\BaseController;

class KelompokPkl extends BaseController
{
    public function __construct()
    {
        $this->user = new User();
        $this->kelompok_model = new KelompokPklModel();
        $this->dospem_model = new DosenPembimbingModel();
        $this->keterangan_kelompok = new KeteranganKelompokPkl();
        $this->jurusan_model = new JurusanModel();
        $this->mahasiswa_model = new Mahasiswa();
        $this->instansi_model = new InstansiPkl();
        $this->pkl_model = new PklModel();
        $this->anggota_pkl_model = new AnggotaPklModel();
        $this->dosen_model = new Dosen();
        $this->db = \Config\Database::connect();
    }

    public function index()
    {
        $rows = $this->pkl_model->select('pkl.id, pkl.nama_kelompok, pkl.tahun_akademik, jurusan.nama_jurusan, dosen_pembimbing.nama_dosen')
            ->join('jurusan', 'jurusan.id_jurusan = pkl.prodi_id', 'left')
            ->join('dosen_pembimbing', 'dosen_pembimbing.id_dosen = pkl.dosen_id', 'left')
            ->findAll();
    
        $mahasiswa = $this->mahasiswa_model->where('status_pkl', 'layak')->findAll();
        $kelompok_list = [];
    
        foreach ($rows as $row) {
            $ketua_kelompok = $this->anggota_pkl_model->select('mahasiswa.nama')
                ->join('mahasiswa', 'mahasiswa.id_mahasiswa = anggota_pkl.mahasiswa_id', 'left')
                ->where('anggota_pkl.pkl_id', $row['id'])
                ->where('anggota_pkl.ketua', 1)
                ->first();
    
            $kelompok_list[] = [
                'id' => $row['id'],
                'nama_kelompok' => $row['nama_kelompok'],
                'tahun_akademik' => $row['tahun_akademik'],
                'nama_jurusan' => $row['nama_jurusan'],
                'nama_dosen' => $row['nama_dosen'],
                'ketua_kelompok' => ($ketua_kelompok) ? $ketua_kelompok['nama'] : ''
            ];
        }
    
        $data = [
            'title' => 'Kelompok PKL',
            'data' => $kelompok_list,
            'data2' => $mahasiswa,
            'dosen' => $this->dosen_model->findAll(),
            'prodi' => $this->jurusan_model->findAll()
        ];
    
        return view('admin/pkl/index', $data);
    }
    
    public function edit($kelompok_id)
    {
        $pkl = $this->pkl_model->find($kelompok_id);
        $info = [
            'title' => 'Edit Kelompok',
            'kelompok_id' => $kelompok_id,
            'kelompok' => $pkl['nama_kelompok'],
            'tahun_akademik' => $pkl['tahun_akademik'],
            'dosen' => $this->dospem_model->findAll(),
            'prodi' => $this->jurusan_model->findAll(),
            'data' => $pkl,
        ];
        return view('admin/pkl/edit', $info);
    }

    public function update_data()
    {
        // Ambil data dari form
        $id = $this->request->getPost('id');
        $tgl_mulai = $this->request->getPost('tgl_mulai');
        $tgl_selesai = $this->request->getPost('tgl_selesai');
        $nama_kelompok = $this->request->getPost('nama_kelompok');
        $prodi_id = $this->request->getPost('prodi_id');
        $dosen_id = $this->request->getPost('dosen_id');
        $tahun_akademik = $this->request->getPost('tahun_akademik');

        // Lakukan validasi data jika diperlukan

        // Update data ke database
        $model = new PklModel();
        $data = [
            'tgl_mulai' => $tgl_mulai,
            'tgl_selesai' => $tgl_selesai,
            'nama_kelompok' => $nama_kelompok,
            'prodi_id' => $prodi_id,
            'dosen_id' => $dosen_id,
            'tahun_akademik' => $tahun_akademik
        ];
        $model->update($id, $data);

        // Set flash data untuk pesan sukses
        $session = session();
        $session->setFlashdata('success', 'Data berhasil diperbarui.');

        // Redirect ke halaman yang diinginkan setelah update
        return redirect()->to(base_url('pkl/kelompok'));
    }

    public function edit_kelompok($kelompok_id)
    {
        $pkl = $this->pkl_model->find($kelompok_id);
        $mahasiswa = $this->mahasiswa_model
            ->where('status_pkl', 'layak')
            ->where('id_jurusan', $pkl['prodi_id']) // Memfilter berdasarkan prodi_id
            ->whereNotIn('id_mahasiswa', function ($builder) use ($kelompok_id) {
                $builder->select('mahasiswa_id')
                    ->from('anggota_pkl')
                    ->where('pkl_id', $kelompok_id);
            })
            ->findAll();

        $rows = $this->db->table('anggota_pkl')
            ->where('pkl_id', $kelompok_id)
            ->join('pkl', 'anggota_pkl.pkl_id = pkl.id')
            ->join('mahasiswa', 'anggota_pkl.mahasiswa_id = mahasiswa.id_mahasiswa')
            ->get()
            ->getResultArray();
        $prodi = $this->jurusan_model->find($pkl['prodi_id']);
        $dosen = $this->dosen_model->find($pkl['dosen_id']);
        $anggota_pkl = $this->anggota_pkl_model->select('mahasiswa_id')->findAll();

        $mahasiswa_pkl = [];

        foreach ($anggota_pkl as $data) {
            array_push($mahasiswa_pkl, $data['mahasiswa_id']);
        }

        $info = [
            'title' => 'Tambah Kelompok',
            'kelompok_id' => $kelompok_id,
            'kelompok' => $pkl['nama_kelompok'],
            'id_kelompok' => $pkl['id'],
            'prodi' => $prodi['nama_jurusan'] ?? '-',
            'tgl_mulai' => $pkl['tgl_mulai'] ?? '-',
            'tgl_selesai' => $pkl['tgl_selesai'] ?? '-',
            'rows' => $rows,
            'mahasiswa' => $mahasiswa,
            'mahasiswa_pkl' => $mahasiswa_pkl,
            'dospem' => $dosen['nama'] ?? '',
            'jurusan' => $this->get_jurusan($rows)
        ];

        // return d($info);

        return view('admin/pkl/tambah-anggota/index', $info);
    }

    public function edit_status()
    {
        $id = $this->request->getVar('id');
        $status = $this->request->getVar('status');

        $data = $this->anggota_pkl_model->find($id);
        $data['ketua'] = ($status == 'Ketua') ? true : false;

        // return d($data);

        $this->anggota_pkl_model->save($data);

        session()->setFlashdata('success', 'Role berhasil diubah!');

        return redirect()->back();
    }

    public function detail_kelompok($kelompok)
    {
        $rows = $this->db->table('anggota_pkl')
            ->where('pkl_id', $kelompok)
            ->join('pkl', 'anggota_pkl.pkl_id = pkl.id')
            ->join('mahasiswa', 'anggota_pkl.mahasiswa_id = mahasiswa.id_mahasiswa')
            ->get()
            ->getResultArray();
        $info = $this->pkl_model->find($kelompok);
        $prodi = $this->jurusan_model->find($info['prodi_id']);

        $data = [
            'title' => 'Tambahkan Kelompok',
            'rows' => $rows,
            'jurusan' => $this->jurusan_model->findAll(),
            'dospem' => $this->dosen_model->findAll(),
            'kelompok' => $kelompok,
            'tgl_mulai' => $info['tgl_mulai'] ?? '',
            'tgl_selesai' => $info['tgl_selesai'] ?? '',
            'prodi' => $info['prodi_id'] ?? '',
            'nama_dospem' => $info['pembimbing_lapangan'] ?? '',
            'tahun_akademik' => $info['tahun_akademik'] ?? '',
            'dosen_id' => $info['dosen_id'] ?? ''
        ];

        // return d($data);

        return view('admin/pkl/tambah-anggota/edit', $data);
    }

    public function simpan_informasi_pkl($kelompok)
    {
        $info = $this->pkl_model->find($kelompok);
        $info['tgl_selesai'] = $this->request->getVar('tgl_selesai');
        $info['tgl_mulai'] = $this->request->getVar('tgl_mulai');
        $info['prodi_id'] = $this->request->getVar('prodi_id');
        $info['dosen_id'] = $this->request->getVar('dosen_id');
        $info['tahun_akademik'] = $this->request->getVar('tahun_akademik');

        $this->pkl_model->save($info);

        session()->setFlashdata('success', 'Data berhasil disimpan');

        return redirect()->back();
    }

    public function update_kelompok($kelompok)
    {
        // return d($this->request->getVar('status_pkl[]'));
        foreach ($this->request->getVar('status_pkl[]') as $row) {
            $data = $this->mahasiswa_model->find(explode('|', $row)[0]);
            $data['status_pkl'] = explode('|', $row)[1];
            $this->mahasiswa_model->save($data);
        }

        session()->setFlashdata('success', 'Data berhasil disimpan');

        return redirect()->to('/pkl/kelompok/edit/' . $kelompok);
    }

    public function detail()
    {
        $data = $this->instansi_model->where('kelompok', $this->request->getVar('kelompok'))->first();

        return $this->response->setJSON($data);
    }

    public function show()
    {
        $result = $this->db->table('kelompok_pkl')
            ->where('id_kelompok', $this->request->getVar('id'))
            ->join('jurusan', 'kelompok_pkl.id_jurusan = jurusan.id_jurusan')
            ->get()
            ->getResultArray();

        return $this->response->setJSON($result[0]);
    }

    public function simpan()
    {
        $data = [
            'tgl_mulai' => $this->request->getVar('tgl_mulai'),
            'tgl_selesai' => $this->request->getVar('tgl_selesai'),
            'nama_kelompok' => $this->request->getVar('nama_kelompok'),
            'tahun_akademik' => $this->request->getVar('tahun_akademik'),
            'prodi_id' => $this->request->getVar('prodi_id'),
            'dosen_id' => $this->request->getVar('dosen_id')
        ];

        // insert data
        $this->pkl_model->insert($data);

        session()->setFlashdata('success', 'Data berhasil disimpan!');

        return redirect()->to('/pkl/kelompok/edit/' . $this->pkl_model->getInsertID());
    }

    public function simpan_anggota()
    {
        $pkl_id = $this->request->getVar('pkl');
        $mahasiswa_id = $this->request->getVar('mahasiswa_id');

        $this->anggota_pkl_model->insert([
            'pkl_id' => $pkl_id,
            'mahasiswa_id' => $mahasiswa_id,
            'ketua' => false,
        ]);

        session()->setFlashdata('success', 'Data berhasil disimpan!');

        return redirect()->back();
    }

    public function update()
    {
        $data = $this->kelompok_model->find($this->request->getVar('id'));
        $data['nama_mhs'] = $this->request->getVar('nama_mhs');
        $data['nim'] = $this->request->getVar('nim');
        $data['kelompok'] = $this->request->getVar('kelompok');
        $data['id_jurusan'] = $this->request->getVar('id_jurusan');
        $data['status'] = $this->request->getVar('status');
        // update data
        $this->kelompok_model->save($data);
        session()->setFlashdata('success', 'Kelompok berhasil diupdate!');
        return redirect()->to('/pkl/kelompok');
    }

    public function delete()
    {
        $this->pkl_model->delete($this->request->getVar('kelompok'));
        $this->anggota_pkl_model
            ->where('pkl_id', $this->request->getVar('kelompok'))
            ->delete();

        session()->setFlashdata('success', 'Kelompok berhasil dihapus!');

        return redirect()->to('/pkl/kelompok');
    }

    public function delete_anggota()
    {
        $this->anggota_pkl_model->delete($this->request->getVar('id'));

        session()->setFlashdata('success', 'Anggota berhasil dihapus!');

        return redirect()->back();
    }
}
