<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class LaporanKkn extends BaseController
{
    public function index()
    {
        //
    }
}
