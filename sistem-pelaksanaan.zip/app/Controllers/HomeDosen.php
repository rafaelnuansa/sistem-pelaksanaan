<?php

namespace App\Controllers;

use Dompdf\Dompdf;
use App\Models\{
    JurnalBimbinganPkl, 
    JadwalPklModel, 
    JurusanModel
};
use App\Controllers\BaseController;

class HomeDosen extends BaseController
{
    public function __construct()
    {
        $this->pdf = new Dompdf();
        $this->jadwal_pkl = new JadwalPklModel();
        $this->db = \Config\Database::connect();
        $this->jurnal_bimbingan = new JurnalBimbinganPkl();
        $this->jurusan_model = new JurusanModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Validasi Bimbingan',
            'data' => $this->jurnal_bimbingan->select('nama_mhs, id_jurnal, status')
                ->groupBy('nama_mhs')
                ->orderBy('nama_mhs')
                ->findAll()
        ];

        return view('dosen/pkl/bimbingan', $data);
    }

    public function bimbingan_detail($nama)
    {
        $rows = $this->jurnal_bimbingan
            ->where('nama_mhs', $nama)
            ->findAll();

        $data = [
            'title' => "Jurnal Bimbingan ($nama)",
            'data' => $rows
        ];

        return view('admin/pkl/jurnal/bimbingan-detail', $data);
    }

    public function penilaian()
    {
        return view('dosen/penilaian_ujian', ['title' => 'Penilaian Ujian']);
    }

    public function penilaian2()
    {
        return view('dosen/penilaian_revisi', ['title' => 'Penilaian revisi']);
    }

    public function detail()
    {
        $result = $this->db->table('jurnal_bimbingan_pkl')
            ->where('id_jurnal', $this->request->getVar('id'))
            ->join('jurusan', 'jurnal_bimbingan_pkl.id_jurusan = jurusan.id_jurusan')
            ->get()
            ->getResultArray();

        return $this->response->setJSON($result[0]);
    }

    public function jadwal_pkl()
    {
        $data = [
            'title' => 'Jadwal Sidang',
            'data' => $this->jadwal_pkl->findAll()
        ];

        return view('admin/pkl/jadwal-sidang', $data);
    }

    public function approve_bimbingan()
    {
        $data = $this->jurnal_bimbingan->where('id_jurnal', $_GET['id'])->first();

        $data['status'] = 'Approved';

        $this->jurnal_bimbingan->save($data);

        session()->setFlashdata('success', 'Berhasil di approve');

        return redirect()->to('/dosen');
    }

    public function cetak()
    {
        $nilai = $this->request->getVar('nilai[]');
        $total_nilai = 0;

        foreach($nilai as $v)  {
            $total_nilai += (int)$v;
        }

        // return d($total_nilai);

        $data = [
            'nama_mhs' => $this->request->getVar('nama_mhs'),
            'nim' => $this->request->getVar('nim'),
            'jurusan' => $this->request->getVar('jurusan'),
            'tahun' => $this->request->getVar('tahun'),
            'judul_skripsi' => $this->request->getVar('judul_skripsi'),
            'komentar' => $this->request->getVar('komentar'),
            'nama_penguji' => $this->request->getVar('nama_penguji'),
            'nidn' => $this->request->getVar('nidn'),
            'tempat_tanggal' => $this->request->getVar('tempat_tanggal'),
            'nilai' => $nilai,
            'total_nilai' => $total_nilai,
        ];

        // load HTML content
        $this->pdf->loadHtml(view('pdf/penilaian_pkl', ['data' => $data]));

        // (optional) setup the paper size and orientation
        $this->pdf->setPaper('A4');

        // render html as PDF
        $this->pdf->render();

        // output the generated pdf
        return $this->pdf->stream('Laporan', array("Attachment" => false));
    }

    public function cetak_revisi()
    {
        $bab = $this->request->getVar('bab[]');
        $uraian = $this->request->getVar('uraian[]');

        // load HTML content
        $this->pdf->loadHtml(view('pdf/lembar_revisi', compact('bab', 'uraian')));

        // (optional) setup the paper size and orientation
        $this->pdf->setPaper('A4');

        // render html as PDF
        $this->pdf->render();

        // output the generated pdf
        return $this->pdf->stream('Laporan', array("Attachment" => false));
    }
}
