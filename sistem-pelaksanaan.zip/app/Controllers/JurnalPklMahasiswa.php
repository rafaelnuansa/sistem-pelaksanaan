<?php

namespace App\Controllers;

use Dompdf\Dompdf;
use App\Models\{
    JurnalPelaksanaanPkl, 
    JurnalBimbinganPkl, 
    JurusanModel,
    JudulLaporanPkl
};
use App\Controllers\BaseController;

class JurnalPklMahasiswa extends BaseController
{
    public function __construct()
    {
        $this->pdf = new Dompdf();
        $this->jurnal_pelaksanaan = new JurnalPelaksanaanPkl();
        $this->jurnal_bimbingan = new JurnalBimbinganPkl();
        $this->jurusan_model = new JurusanModel();
        $this->judul_laporan = new JudulLaporanPkl();
        $this->db = \Config\Database::connect();
    }

    public function pelaksanaan()
    {
        $data = [
            'title' => 'Jurnal Pelaksanaan',
            'data' => $this->jurnal_pelaksanaan->where('kelompok', session()->get('kelompok'))->findAll()
        ];

        return view('mahasiswa/pkl/jurnal/pelaksanaan', $data);
    }

    public function bimbingan()
    {
        $judul_laporan = $this->judul_laporan->where('user_id', session()->get('id'))->first();
        $data = [
            'title' => 'Jurnal Bimbingan',
            'data' => $this->jurnal_bimbingan->where('kelompok', session()->get('kelompok'))->findAll(),
            'judul_laporan' => ($judul_laporan != null) ? $judul_laporan['judul'] : null
        ];

        // return d($data);

        return view('mahasiswa/pkl/jurnal/bimbingan', $data);
    }

    public function simpan_judul()
    {

        $this->judul_laporan->insert([
            'judul' => $this->request->getVar('judul_laporan'),
            'user_id' => session()->get('id')
        ]);

        session()->setFlashdata('success', 'Judul berhasil disimpan!');

        return redirect()->to('/mahasiswa/pkl/jurnal/bimbingan');
    }

    public function approve($id)
    {
        $data = $this->jurnal_pelaksanaan->find($id);
        $data['status'] = 'Approved';

        $this->jurnal_pelaksanaan->save($data);

        session()->setFlashdata('success', 'Jurnal berhasil di validasi!');

        return redirect()->to('/mahasiswa/pkl/jurnal/pelaksanaan');
    }

    public function unapprove2($id)
    {
        $data = $this->jurnal_bimbingan->find($id);
        $data['status'] = 'Pending';

        $this->jurnal_bimbingan->save($data);

        session()->setFlashdata('success', 'Jurnal berhasil di validasi!');

        return redirect()->to('/mahasiswa/pkl/jurnal/bimbingan');
    }

    public function approve2($id)
    {
        $data = $this->jurnal_bimbingan->find($id);
        $data['status'] = 'Approved';

        $this->jurnal_bimbingan->save($data);

        session()->setFlashdata('success', 'Jurnal berhasil di validasi!');

        return redirect()->to('/mahasiswa/pkl/jurnal/bimbingan');
    }

    public function simpan()
    {
        $data = [
            'nama_mhs' => session()->get('nama'), 
            'jam' => $this->request->getVar('jam'), 
            'hari' => $this->request->getVar('hari'), 
            'keterangan' => $this->request->getVar('keterangan'),
            'kelompok' => session()->get('kelompok')
        ];

        // insert data
        $this->jurnal_pelaksanaan->insert($data);

        session()->setFlashdata('success', 'Data berhasil disimpan!');

        return redirect()->to('/mahasiswa/pkl/jurnal/pelaksanaan');
    }

    public function simpan2()
    {

        $data = [
            'jam' => $this->request->getVar('jam'),
            'tanggal' => $this->request->getVar('tanggal'),
            'nama_mhs' => session()->get('nama'),
            'catatan' => $this->request->getVar('keterangan'),
            'kelompok' => session()->get('kelompok')
        ];

        // insert data
        $this->jurnal_bimbingan->insert($data);

        session()->setFlashdata('success', 'Data berhasil disimpan!');

        return redirect()->to('/mahasiswa/pkl/jurnal/bimbingan');
    }

    public function log_harian()
    {
        $title = 'Log harian';
        $data = $this->jurnal_pelaksanaan->where('kelompok', session()->get('kelompok'))->findAll();
        $total = $this->jurnal_pelaksanaan->where('kelompok', session()->get('kelompok'))->countAllResults();

        // load HTML content
        $this->pdf->loadHtml(view('pdf/jurnal/pelaksanaan_pkl', compact('data', 'total', 'title')));

        // (optional) setup the paper size and orientation
        $this->pdf->setPaper('A4', 'landscape');

        // render html as PDF
        $this->pdf->render();

        // output the generated pdf
        return $this->pdf->stream('Log Harian', array("Attachment" => false));
    }
}
