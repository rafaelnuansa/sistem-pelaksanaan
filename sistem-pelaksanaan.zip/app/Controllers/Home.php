<?php

namespace App\Controllers;

use App\Models\{
    UjianPklModel,
    JurnalBimbinganPkl,
    JadwalPklModel,
    DosenPembimbingModel,
    KelompokPklModel
};

class Home extends BaseController
{
    public function __construct()
    {
        $this->ujian_model = new UjianPklModel();
        $this->jurnal_bimbingan = new JurnalBimbinganPkl();
        $this->jadwal_pkl = new JadwalPklModel();
        $this->dosen_pembimbing = new DosenPembimbingModel();
        $this->kelompok_model = new KelompokPklModel();
        $this->db = \Config\Database::connect();
    }

    public function index()
    {
        $total_pendaftaran = $this->kelompok_model
            ->groupBy('kelompok, tahun_akademik')
            ->findAll();
        $total_pendaftaran = count($total_pendaftaran);
        $total_bimbingan = $this->jurnal_bimbingan->countAll();
        $total_jadwal = $this->jadwal_pkl->countAll();
        $total_dosen = $this->dosen_pembimbing->countAll();

        $data = [
            'title' => 'Dashboard',
            'total_pendaftaran' => $total_pendaftaran,
            'total_bimbingan' => $total_bimbingan,
            'total_jadwal' => $total_jadwal,
            'total_dosen' => $total_dosen,
        ];

        return view('admin/dashboard', $data);
    }

    public function login()
    {
        if(session()->get('logged_in')) {
            if(session()->get('level') == 'Mahasiswa') {
                return redirect()->to('/mahasiswa');
            }

            if(session()->get('level') == 'Dosen') {
                return redirect()->to('/dosen');
            }

            return redirect()->to('/dashboard');
        }

        return view('login');
    }
}
