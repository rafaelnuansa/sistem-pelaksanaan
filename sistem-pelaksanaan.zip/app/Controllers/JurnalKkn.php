<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class JurnalKkn extends BaseController
{
    public function index()
    {
        //
    }
}
