<?php

namespace App\Controllers;

use Dompdf\Dompdf;
use App\Models\{
    KelompokPklModel,
    JurnalPelaksanaanPkl,
    JurnalBimbinganPkl,
    JadwalPklModel,
    DosenPembimbingModel
};
use App\Controllers\BaseController;

class CetakLaporan extends BaseController
{
    public function __construct()
    {
        $this->pdf = new Dompdf();
        $this->db = \Config\Database::connect();
        $this->kelompok_model = new KelompokPklModel();
        $this->jurnal_pelaksanaan = new JurnalPelaksanaanPkl();
        $this->jurnal_bimbingan = new JurnalBimbinganPkl();
        $this->jadwal_pkl = new JadwalPklModel();
        $this->dosen_pembimbing = new DosenPembimbingModel();
    }

    public function index()
    {
        return view('admin/laporan', ['title' => 'Cetak Laporan']);
    }

    public function cetak_pkl()
    {
        $title = 'Laporan Kelompok PKL';
        $data = $this->db->table('kelompok_pkl')
            ->select('*')
            ->join('jurusan', 'kelompok_pkl.id_jurusan = jurusan.id_jurusan')
            ->get()
            ->getResultArray();
        $total = $this->kelompok_model->countAll();

        // load HTML content
        $this->pdf->loadHtml(view('pdf/kelompok_pkl', compact('data', 'total', 'title')));

        // (optional) setup the paper size and orientation
        $this->pdf->setPaper('A4', 'landscape');

        // render html as PDF
        $this->pdf->render();

        // output the generated pdf
        return $this->pdf->stream('Laporan', array("Attachment" => false));
    }

    public function cetak_jurnal1()
    {
        $type = $_GET['type'];

        if($type == 'pkl') {
            $title = 'Laporan Jurnal Pelaksanaan PKL';
            $data = $this->jurnal_pelaksanaan->findAll();
            $total = $this->jurnal_pelaksanaan->countAll();

            // load HTML content
            $this->pdf->loadHtml(view('pdf/jurnal/pelaksanaan_pkl', compact('data', 'total', 'title')));
        }
        

        // (optional) setup the paper size and orientation
        $this->pdf->setPaper('A4', 'landscape');

        // render html as PDF
        $this->pdf->render();

        // output the generated pdf
        return $this->pdf->stream('Laporan', array("Attachment" => false));
    }

    public function cetak_jurnal2()
    {
        $type = $_GET['type'];

        if($type == 'pkl') {
            $title = 'Laporan Jurnal Bimbingan PKL';
            $data = $this->jurnal_bimbingan->getAll();
            $total = $this->jurnal_bimbingan->countAll();

            // load HTML content
            $this->pdf->loadHtml(view('pdf/jurnal/bimbingan_pkl', compact('data', 'total', 'title')));
        }
        

        // (optional) setup the paper size and orientation
        $this->pdf->setPaper('A4', 'landscape');

        // render html as PDF
        $this->pdf->render();

        // output the generated pdf
        return $this->pdf->stream('Laporan', array("Attachment" => false));
    }

    public function cetak_jadwal_pkl()
    {
        $title = 'Laporan Jadwal Sidang PKL';
        $data = $this->jadwal_pkl->findAll();
        $total = $this->jadwal_pkl->countAll();

        // load HTML content
        $this->pdf->loadHtml(view('pdf/jadwal_pkl', compact('data', 'total', 'title')));

        // (optional) setup the paper size and orientation
        $this->pdf->setPaper('A4', 'landscape');

        // render html as PDF
        $this->pdf->render();

        // output the generated pdf
        return $this->pdf->stream('Laporan', array("Attachment" => false));
    }

    public function cetak_dospem()
    {
        $title = 'Laporan Dosen Pembimbing';
        $data = $this->dosen_pembimbing->findAll();
        $total = $this->dosen_pembimbing->countAll();

        // load HTML content
        $this->pdf->loadHtml(view('pdf/dosen_pembimbing', compact('data', 'total', 'title')));

        // (optional) setup the paper size and orientation
        $this->pdf->setPaper('A4', 'landscape');

        // render html as PDF
        $this->pdf->render();

        // output the generated pdf
        return $this->pdf->stream('Laporan', array("Attachment" => false));
    }
}
