<?php

namespace App\Controllers;

use App\Models\{
    JurnalPelaksanaanPkl, 
    JurnalBimbinganPkl
};
use App\Controllers\BaseController;

class JurnalPkl extends BaseController
{
    public function __construct()
    {
        $this->jurnal_pelaksanaan = new JurnalPelaksanaanPkl();
        $this->jurnal_bimbingan = new JurnalBimbinganPkl();
        $this->db = \Config\Database::connect();
    }

    public function pelaksanaan()
    {
        $rows = $this->jurnal_pelaksanaan->select('nama_mhs')
            ->groupBy('nama_mhs')
            ->orderBy('nama_mhs')
            ->findAll();

        $data = [
            'title' => 'Jurnal Pelaksanaan',
            'data' => $rows
        ];

        return view('admin/pkl/jurnal/pelaksanaan', $data);
    }

    public function pelaksanaan_detail($nama)
    {
        $rows = $this->jurnal_pelaksanaan
            ->where('nama_mhs', $nama)
            ->findAll();

        $data = [
            'title' => "Jurnal Pelaksanaan ($nama)",
            'data' => $rows
        ];

        return view('admin/pkl/jurnal/pelaksanaan-detail', $data);
    }

    public function bimbingan()
    {
        $data = [
            'title' => 'Jurnal Bimbingan',
            'data' => $this->jurnal_bimbingan->select('nama_mhs')
                ->groupBy('nama_mhs')
                ->orderBy('nama_mhs')
                ->findAll()
        ];

        return view('admin/pkl/jurnal/bimbingan', $data);
    }

    public function bimbingan_detail($nama)
    {
        $rows = $this->jurnal_bimbingan
            ->where('nama_mhs', $nama)
            ->findAll();

        $data = [
            'title' => "Jurnal Bimbingan ($nama)",
            'data' => $rows
        ];

        return view('admin/pkl/jurnal/bimbingan-detail', $data);
    }

    public function simpan()
    {
        $data = [
            'jam' => $this->request->getVar('jam'), 
            'hari' => $this->request->getVar('hari'), 
            'keterangan' => $this->request->getVar('keterangan'), 
            'dpl' => $this->request->getVar('dpl')
        ];

        // insert data
        $this->jurnal_pelaksanaan->insert($data);

        session()->setFlashdata('success', 'Data berhasil disimpan!');

        return redirect()->to('/pkl/jurnal/pelaksanaan');
    }

    public function delete()
    {
        $this->jurnal_pelaksanaan->delete($this->request->getVar('id'));

        session()->setFlashdata('success', 'Jurnal berhasil dihapus!');

        return redirect()->to('/pkl/jurnal/pelaksanaan');
    }
}
