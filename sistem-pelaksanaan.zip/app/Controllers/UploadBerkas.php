<?php

namespace App\Controllers;

use App\Models\BerkasModel;
use App\Controllers\BaseController;

class UploadBerkas extends BaseController
{
    public function __construct()
    {
        $this->berkas = new BerkasModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Upload Berkas',
            'data' => $this->berkas->findAll()
        ];

        return view('upload_berkas', $data);
    }

    public function simpan()
    {
        $upload_file = $this->request->getFile('file');

        $file = $upload_file->getRandomName();
        $upload_file->move('uploads/berkas/', $file);

        $data = [
            'file' => $file,
            'nama_file' => $this->request->getVar('nama_file'),
            'jenis' => $this->request->getVar('jenis'),
            'keterangan' => $this->request->getVar('keterangan'),
            'tanggal' => $this->request->getVar('tanggal')
        ];

        $this->berkas->insert($data);

        session()->setFlashdata('success', 'Data berhasil di upload!');

        return redirect()->to('/mahasiswa/upload-berkas');
    }

    public function delete()
    {
        $this->berkas->delete($this->request->getVar('id'));

        session()->setFlashdata('success', 'Berkas berhasil dihapus!');

        return redirect()->to('/mahasiswa/upload-berkas');
    }
}
