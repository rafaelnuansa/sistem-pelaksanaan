<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class KelompokKkn extends BaseController
{
    public function index()
    {
        //
    }
}
