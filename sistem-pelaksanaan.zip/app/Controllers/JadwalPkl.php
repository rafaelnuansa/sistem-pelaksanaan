<?php

namespace App\Controllers;

use App\Models\{
    JadwalPklModel,
    JurusanModel,
    UjianPklModel,
};
use App\Controllers\BaseController;

class JadwalPkl extends BaseController
{
    public function __construct()
    {
        $this->jadwal_pkl = new JadwalPklModel();
        $this->jurusan_model = new JurusanModel();
        $this->ujian_pkl = new UjianPklModel();
        $this->db = \Config\Database::connect();
    }

    public function index()
    {
        $pending = $this->ujian_pkl->where('status', 'Pending')->findAll();
        $data = [
            'title' => 'Jadwal Sidang',
            'data' => $this->jadwal_pkl->findAll(),
            'pending' => $pending,
            'jurusan' => $this->jurusan_model->findAll()
        ];

        return view('admin/pkl/jadwal-sidang', $data);
    }

    public function mahasiswa()
    {
        $data = [
            'title' => 'Jadwal Sidang',
            'data' => $this->jadwal_pkl->where('user_id', session()->get('id'))->findAll(),
            'jurusan' => $this->jurusan_model->findAll()
        ];

        return view('mahasiswa/pkl/jadwal-sidang', $data);
    }

    public function show()
    {
        $result = $this->db->table('ujian_pkl')
            ->where('id_ujian_pkl', $this->request->getVar('id'))
            ->join('jurusan', 'ujian_pkl.id_jurusan = jurusan.id_jurusan')
            ->get()
            ->getResultArray();

        return $this->response->setJSON($result[0]);
    }

    public function simpan()
    {
        $data = [
            'tanggal' => $this->request->getVar('tanggal'),
            'nama' => $this->request->getVar('nama'),
            'nim' => $this->request->getVar('nim'),
            'keterangan' => $this->request->getVar('keterangan'),
            'dospem' => $this->request->getVar('dospem'),
            'dospeng' => $this->request->getVar('dospeng'),
            'tempat' => $this->request->getVar('tempat'),
            'user_id' => $this->request->getVar('user_id')
        ];

        $this->jadwal_pkl->insert($data);

        $ujian = $this->ujian_pkl->find($this->request->getVar('id_daftar'));
        // return d($ujian);
        $ujian['status'] = 'Approved';
        $this->ujian_pkl->save($ujian);

        session()->setFlashdata('success', 'Jadwal berhasil ditambahkan!');

        return redirect()->to('/pkl/jadwal');
    }

    public function update_status($id_jadwal_sidang, $status)
    {
        // Lakukan pembaruan status pada data dengan $id_jadwal_sidang
        // Misalnya, Anda dapat menggunakan model atau metode lain untuk melakukan pembaruan di database
    
        // Contoh menggunakan model
        $this->jadwal_pkl->update($id_jadwal_sidang, ['status' => $status]);
    
        // Redirect ke halaman sebelumnya
        return redirect()->back();
    }
    
}
