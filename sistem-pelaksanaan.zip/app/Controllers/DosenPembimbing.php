<?php

namespace App\Controllers;

use App\Models\DosenPembimbingModel;
use App\Controllers\BaseController;

class DosenPembimbing extends BaseController
{
    public function __construct()
    {
        $this->dosen_pembimbing = new DosenPembimbingModel();
    }

    public function index()
    {
        $rows = $this->dosen_pembimbing->findAll();

        $data = [
            'title' => 'Dosen Pembimbing',
            'data' => $rows,
        ];

        return view('admin/dosen_pembimbing', $data);
    }

    public function simpan()
    {
        $data = [
            'nama_dosen' => $this->request->getVar('nama_dosen'), 
            'nama_mhs' => $this->request->getVar('nama_mhs'), 
            'nim' => $this->request->getVar('nim'), 
            'keterangan' => $this->request->getVar('keterangan')
        ];

        // insert data
        $this->dosen_pembimbing->insert($data);

        session()->setFlashdata('success', 'Data berhasil disimpan!');

        return redirect()->to('/dosen_pembimbing');
    }

    public function delete()
    {
        $this->dosen_pembimbing->delete($this->request->getVar('id'));

        session()->setFlashdata('success', 'Dospem berhasil dihapus!');

        return redirect()->to('/dosen_pembimbing');
    }
}
