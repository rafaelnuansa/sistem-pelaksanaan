<?php

namespace App\Controllers;

use App\Models\User;
use App\Controllers\BaseController;

class DaftarAkun extends BaseController
{
    public function __construct()
    {
        $this->user = new User();
    }

    public function index()
    {
        $data = [
            'title' => 'Daftar Akun',
            'users' => $this->user->findAll()
        ];

        return view('admin/user', $data);
    }

    public function show()
    {
        $result = $this->user->find($this->request->getVar('id'));

        return $this->response->setJSON($result);
    }

    public function simpan()
    {
        $data = [
            'nama' => $this->request->getVar('nama'),
            'username' => $this->request->getVar('username'),
            'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT),
            'level' => $this->request->getVar('level')
        ];

        // insert data
        $this->user->insert($data);

        session()->setFlashdata('success', 'Akun berhasil dibuat!');

        return redirect()->to('/akun');
    }

    public function update()
    {
        $data = $this->user->find($this->request->getVar('id'));

        $data['nama'] = $this->request->getVar('nama');
        $data['username'] = $this->request->getVar('username');
        $data['level'] = $this->request->getVar('level');

        if($this->request->getVar('password') !== '') {
            $data['password'] = password_hash($this->request->getVar('password'), PASSWORD_DEFAULT);
        }

        // update data
        $this->user->save($data);

        session()->setFlashdata('success', 'Akun berhasil diupdate!');

        return redirect()->to('/akun');
    }

    public function delete()
    {
        $this->user->delete($this->request->getVar('id'));

        session()->setFlashdata('success', 'Akun berhasil dihapus!');

        return redirect()->to('/akun');
    }
}
