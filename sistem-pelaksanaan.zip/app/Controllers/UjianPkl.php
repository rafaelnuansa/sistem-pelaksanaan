<?php

namespace App\Controllers;

use App\Models\{JurusanModel, UjianPklModel};
use App\Controllers\BaseController;

class UjianPkl extends BaseController
{
    public function index()
    {
        $jurusan = new JurusanModel();
        return view('mahasiswa/pkl/daftar-ujian', [
            'title' => 'Pendaftaran Ujian PKL',
            'jurusan' => $jurusan->findAll()
        ]);
    }

    public function simpan()
    {
        $ujian = new UjianPklModel();

        $lampiran_pembayaran = $this->request->getFile('lampiran_pembayaran');
        $lampiran_krs = $this->request->getFile('lampiran_krs');
        $lampiran_laporan = $this->request->getFile('lampiran_laporan');
        $lampiran_keterangan = $this->request->getFile('lampiran_keterangan');

        $file2 = $lampiran_pembayaran->getRandomName();
        $file3 = $lampiran_krs->getRandomName();
        $file4 = $lampiran_laporan->getRandomName();
        $file5 = $lampiran_keterangan->getRandomName();

        $lampiran_pembayaran->move('uploads/pkl/', $file2);
        $lampiran_krs->move('uploads/pkl/', $file3);
        $lampiran_laporan->move('uploads/pkl/', $file4);
        $lampiran_keterangan->move('uploads/pkl/', $file5);

        $data = [
            'nama' => session()->get('nama'),
            'lampiran_pembayaran' => $file2,
            'lampiran_krs' => $file3,
            'lampiran_laporan' => $file4,
            'lampiran_keterangan' => $file5,
            'user_id' => session()->get('id')
        ];

        $ujian->insert($data);

        session()->setFlashdata('success', 'Berhasil melakukan pendaftaran');
        return redirect()->to('/mahasiswa/pkl/jadwal');
    }
}
