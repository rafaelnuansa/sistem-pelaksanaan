<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class MahasiswaSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'nama' => 'Asih Tri Indriyani', 
                'nim' => '42139005',
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'layak',
                'id_jurusan' => 2
            ],
            [
                'nama' => 'kharisma desti p', 
                'nim' => '42319001', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'layak',
                'id_jurusan' => 1
            ],
            [
                'nama' => 'Azis maulana', 
                'nim' => '42319002', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2002-07-05',
                'angkatan' => '2019',
                'status_pkl' => 'belum layak',
                'id_jurusan' => 2
            ],
            [
                'nama' => 'Nina Melani', 
                'nim' => '42319003', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2002-09-10',
                'angkatan' => '2019',
                'status_pkl' => 'sudah pkl',
                'id_jurusan' => 2
            ],
            [
                'nama' => 'Rifta Rismayasari', 
                'nim' => '4239004', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'layak',
                'id_jurusan' => 2
            ],
            [
                'nama' => 'Shodik Abdul ghofar', 
                'nim' => '42319006', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'sudah pkl',
                'id_jurusan' => 3
            ],
            [
                'nama' => 'M. Wildan ihsani', 
                'nim' => '42319008', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'belum layak',
                'id_jurusan' => 1
            ],
            [
                'nama' => 'Deskal Dwi Rayananda', 
                'nim' => '42319010', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'sudah pkl',
                'id_jurusan' => 4
            ],
            [
                'nama' => 'Ahmad Munibi', 
                'nim' => '42319012', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'belum layak',
                'id_jurusan' => 4
            ],
            [
                'nama' => 'Inayatul ulfiana', 
                'nim' => '423190013', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'layak',
                'id_jurusan' => 2
            ],
            [
                'nama' => 'M. Rafi Syabana', 
                'nim' => '423190014', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'layak',
                'id_jurusan' => 2
            ],
            [
                'nama' => 'Melly Ayu Fajriyan', 
                'nim' => '423190017', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'layak',
                'id_jurusan' => 2
            ],
            [
                'nama' => 'Tedy Ega', 
                'nim' => '423190019', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'belum layak',
                'id_jurusan' => 5
            ],
            [
                'nama' => 'Neli Sa\'adah', 
                'nim' => '42319020', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'layak',
                'id_jurusan' => 5
            ],
            [
                'nama' => 'Arum Tri Indriyana', 
                'nim' => '42319021', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'sudah pkl',
                'id_jurusan' => 5
            ],
            [
                'nama' => 'Azkiya', 
                'nim' => '42319022', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'layak',
                'id_jurusan' => 3
            ],
            [
                'nama' => 'Assyfa Hanum', 
                'nim' => '42319023', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'layak',
                'id_jurusan' => 2
            ],
            [
                'nama' => 'Rizaldi M', 
                'nim' => '42319024', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'belum layak',
                'id_jurusan' => 2
            ],
            [
                'nama' => 'M. Ivandi', 
                'nim' => '42319025', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'belum layak',
                'id_jurusan' => 3
            ],
            [
                'nama' => 'Dini Putri', 
                'nim' => '42319027', 
                'no_telpon' => '085436788098', 
                'alamat' => 'Bumiayu',
                'jenis_kelamin' => 'P',
                'tgl_lahir' => '2000-10-01',
                'angkatan' => '2019',
                'status_pkl' => 'layak',
                'id_jurusan' => 5
            ],
        ];

        $this->db->table('mahasiswa')->insertBatch($data);
    }
}
