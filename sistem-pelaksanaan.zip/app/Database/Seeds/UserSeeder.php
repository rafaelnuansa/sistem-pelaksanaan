<?php

namespace App\Database\Seeds;

use App\Models\User;
use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        $user = new User();
        $data = [
            [
                'nama' => 'Admin',
                'username' => 'admin',
                'password' => password_hash('admin123', PASSWORD_DEFAULT),
                'level' => 'Admin'
            ],
            [
                'nama' => 'Yusuf Yudhistira, M',
                'username' => 'yusuf',
                'password' => password_hash('123', PASSWORD_DEFAULT),
                'level' => 'Dosen'
            ],
            [
                'nama' => 'Fuaida Nabyla',
                'username' => 'fuaida',
                'password' => password_hash('123', PASSWORD_DEFAULT),
                'level' => 'Dosen'
            ]
        ];

        $user->insert([
                'nama' => 'Asih Tri Indriyani',
                'username' => 'asih',
                'password' => password_hash('123', PASSWORD_DEFAULT),
                'level' => 'Mahasiswa',
                'kelompok' => 1
        ]);

        $user->insertBatch($data);
    }
}
