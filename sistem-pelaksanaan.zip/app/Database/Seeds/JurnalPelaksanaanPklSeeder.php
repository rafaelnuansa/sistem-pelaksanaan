<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class JurnalPelaksanaanPklSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'jam' => '12:00', 
                'hari' => '19-05-2023', 
                'keterangan' => 'Bersih-bersih',
                'kelompok' => 3,
                'nama_mhs' => 'Asih'
            ],
            [
                'jam' => '00:00', 
                'hari' => '20-05-2023', 
                'keterangan' => 'Siskamling',
                'kelompok' => 3,
                'nama_mhs' => 'Asih'
            ],
            [
                'jam' => '05:30', 
                'hari' => '20-05-2023', 
                'keterangan' => 'Cuci baju',
                'kelompok' => 1,
                'nama_mhs' => 'Asih'
            ],
            [
                'jam' => '08:30', 
                'hari' => '20-05-2023', 
                'keterangan' => 'Sosialisasi',
                'kelompok' => 1,
                'nama_mhs' => 'Dewi'
            ]
        ];

        $this->db->table('jurnal_pelaksanaan_pkl')->insertBatch($data);
    }
}
