<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class DataSeeder extends Seeder
{
    public function run()
    {
        // Reset data
        $this->db->table('users')->truncate();
        $this->db->table('jurusan')->truncate();
        $this->db->table('jurnal_pelaksanaan_pkl')->truncate();
        $this->db->table('jurnal_bimbingan_pkl')->truncate();
        $this->db->table('jadwal_sidang_pkl')->truncate();
        $this->db->table('dosen_pembimbing')->truncate();
        $this->db->table('mahasiswa')->truncate();
        $this->db->table('pkl')->truncate();
        $this->db->table('anggota_pkl')->truncate();
        $this->db->table('dosen')->truncate();

        // Seeding
        $this->call('UserSeeder');
        $this->call('JurusanSeeder');
        $this->call('JurnalPelaksanaanPklSeeder');
        $this->call('JurnalBimbinganPklSeeder');
        $this->call('JadwalPklSeeder');
        $this->call('DospemSeeder');
        $this->call('MahasiswaSeeder');
        $this->call('PklSeeder');
        $this->call('AnggotaPklSeeder');
        $this->call('DosenSeeder');
    }
}
