<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class JurnalBimbinganPklSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'tanggal' => '11-05-2023',
                'jam' => '10:00',
                'nama_mhs' => 'Asih',
                'catatan' => 'PKL',
                'kelompok' => 1
            ],
            [
                'tanggal' => '11-06-2023',
                'jam' => '12:00',
                'nama_mhs' => 'Asih',
                'catatan' => 'PKL',
                'kelompok' => 1
            ],
            [
                'tanggal' => '11-07-2023',
                'jam' => '13:00',
                'nama_mhs' => 'Asih',
                'catatan' => 'PKL',
                'kelompok' => 1
            ],
            [
                'tanggal' => '11-07-2023',
                'jam' => '18:30',
                'nama_mhs' => 'Dewi',
                'catatan' => 'PKL',
                'kelompok' => 2
            ]
        ];

        $this->db->table('jurnal_bimbingan_pkl')->insertBatch($data);
    }
}
