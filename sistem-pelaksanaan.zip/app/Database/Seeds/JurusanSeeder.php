<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class JurusanSeeder extends Seeder
{
    public function run()
    {
        $data = [
            ['nama_jurusan' => 'Informatika'],
            ['nama_jurusan' => 'Sistem Informasi'],
            ['nama_jurusan' => 'Farmasi'],
            ['nama_jurusan' => 'Agribisnis'],
            ['nama_jurusan' => 'Teknik Elektro']
        ];

        $this->db->table('jurusan')->insertBatch($data);
    }
}
