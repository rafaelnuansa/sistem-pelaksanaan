<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateJadwalSidangPklTable extends Migration
{
    public function up() {
        $this->forge->addField([
            'id_jadwal_sidang' => [
                'type' => 'BIGINT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'tanggal' => [
                'type'       => 'VARCHAR',
                'constraint' => '50'
            ],
            'nama' => [
                'type'       => 'VARCHAR',
                'constraint' => '120'
            ],
            'nim' => [
                'type'       => 'VARCHAR',
                'constraint' => '20'
            ],
            'keterangan' => [
                'type'       => 'TEXT'
            ],
            'nama' => [
                'type'       => 'VARCHAR',
                'constraint' => '120'
            ],
            'dospem' => [
                'type'       => 'VARCHAR',
                'constraint' => '120'
            ],
            'dospeng' => [
                'type'       => 'VARCHAR',
                'constraint' => '120'
            ],
            'tempat' => [
                'type'       => 'VARCHAR',
                'constraint' => '120'
            ],
            'user_id' => [
                'type'       => 'BIGINT'
            ],
        ]);
        $this->forge->addKey('id_jadwal_sidang', true, true);
        $this->forge->createTable('jadwal_sidang_pkl');
    }

    public function down()
    {
        $this->forge->dropTable('jadwal_sidang_pkl');
    }
}
