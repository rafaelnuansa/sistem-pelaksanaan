<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateJurnalPelaksanaanTable extends Migration
{
   public function up()
    {
        $this->forge->addField([
            'id_jurnal' => [
                'type' => 'BIGINT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'nama_mhs' => [
                'type'       => 'VARCHAR',
                'constraint' => '20'
            ],
            'jam' => [
                'type'       => 'VARCHAR',
                'constraint' => '10'
            ],
            'hari' => [
                'type'       => 'VARCHAR',
                'constraint' => '20'
            ],
            'keterangan' => [
                'type'       => 'TEXT'
            ],
            'kelompok' => [
                'type'       => 'INT',
                'constraint' => 5
            ],
            'status' => [
                'type'       => 'VARCHAR',
                'constraint' => '10',
                'default' => 'Pending'
            ]
        ]);
        $this->forge->addKey('id_jurnal', true, true);
        $this->forge->createTable('jurnal_pelaksanaan_pkl');
    }

    public function down()
    {
        $this->forge->dropTable('jurnal_pelaksanaan_pkl');
    }
}
