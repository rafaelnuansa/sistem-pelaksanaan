<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateLaporanKknTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id_laporan' => [
                'type' => 'BIGINT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'hari' => [
                'type'       => 'VARCHAR',
                'constraint' => '120'
            ],
            'nama_mhs' => [
                'type'       => 'VARCHAR',
                'constraint' => '120'
            ],
            'catatan' => [
                'type'       => 'TEXT'
            ],
            'id_jurusan' => [
                'type'       => 'INT',
                'constraint' => 5,
                'unsigned' => true
            ]
        ]);
        $this->forge->addKey('id_laporan', true, true);
        $this->forge->createTable('laporan_kkn');
    }

    public function down()
    {
        $this->forge->dropTable('laporan_kkn');
    }
}
