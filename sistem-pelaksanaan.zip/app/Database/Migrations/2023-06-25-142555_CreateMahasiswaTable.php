<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateMahasiswaTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id_mahasiswa' => [
                'type' => 'BIGINT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'nama' => [
                'type'       => 'VARCHAR',
                'constraint' => '120'
            ],
            'nim' => [
                'type'       => 'VARCHAR',
                'constraint' => '20'
            ],
            'jenis_kelamin' => [
                'type'       => 'VARCHAR',
                'constraint' => '10'
            ],
            'no_telpon' => [
                'type'       => 'VARCHAR',
                'constraint' => '120'
            ],
            'tgl_lahir' => [
                'type'       => 'VARCHAR',
                'constraint' => '120'
            ],
            'alamat' => [
                'type'       => 'TEXT'
            ],
            'angkatan' => [
                'type'       => 'VARCHAR',
                'constraint' => '20'
            ],
            'status_pkl' => [
                'type'       => 'VARCHAR',
                'constraint' => '20'
            ],
            'id_jurusan' => [
                'type'       => 'INT',
                'constraint' => 5,
                'unsigned' => true
            ]
        ]);
        $this->forge->addKey('id_mahasiswa', true, true);
        $this->forge->createTable('mahasiswa');
    }

    public function down()
    {
        $this->forge->dropTable('mahasiswa');
    }
}
