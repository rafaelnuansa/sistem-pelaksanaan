<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateDosenPembimbingTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id_dosen' => [
                'type' => 'BIGINT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'nama_dosen' => [
                'type'       => 'VARCHAR',
                'constraint' => '120'
            ],
            'nama_mhs' => [
                'type'       => 'VARCHAR',
                'constraint' => '120'
            ],
            'nim' => [
                'type'       => 'VARCHAR',
                'constraint' => '20'
            ],
            'keterangan' => [
                'type'       => 'VARCHAR',
                'constraint' => '120'
            ]
        ]);
        $this->forge->addKey('id_dosen', true, true);
        $this->forge->createTable('dosen_pembimbing');
    }

    public function down()
    {
        $this->forge->dropTable('dosen_pembimbing');
    }
}
