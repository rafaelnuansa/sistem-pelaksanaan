<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateAnggotaPklTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id_anggota' => [
                'type' => 'BIGINT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'mahasiswa_id' => [
                'type' => 'BIGINT'
            ],
            'pkl_id' => [
                'type' => 'BIGINT'
            ],
            'ketua' => [
                'type' => 'BOOLEAN'
            ]
        ]);
        $this->forge->addKey('id_anggota', true, true);
        $this->forge->createTable('anggota_pkl');
    }

    public function down()
    {
        $this->forge->dropTable('anggota_pkl');
    }
}
