<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateKelompokKknTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id_kelompok' => [
                'type' => 'BIGINT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'nama_mhs' => [
                'type'       => 'VARCHAR',
                'constraint' => '120'
            ],
            'nim' => [
                'type'       => 'VARCHAR',
                'constraint' => '20'
            ],
            'dospem' => [
                'type'       => 'VARCHAR',
                'constraint' => '120'
            ],
            'tempat_kkn' => [
                'type'       => 'VARCHAR',
                'constraint' => '120'
            ],
            'kelompok' => [
                'type'       => 'VARCHAR',
                'constraint' => '20'
            ],
            'id_jurusan' => [
                'type'       => 'INT',
                'constraint' => 5,
                'unsigned' => true
            ]
        ]);
        $this->forge->addKey('id_kelompok', true, true);
        $this->forge->createTable('kelompok_kkn');
    }

    public function down()
    {
        $this->forge->dropTable('kelompok_kkn');
    }
}
