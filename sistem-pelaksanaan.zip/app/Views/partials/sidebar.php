<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- /.search form -->
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu" data-widget="tree">
      <li class="header">MENU</li>
      <li class="<?= (uri_string() == 'dashboard') ? 'active' : '' ?>">
        <a href="<?= base_url('dashboard') ?>">
          <i class="fa fa-home"></i> <span>Dashboard</span>
        </a>
      </li>
      <li class="treeview <?= (uri_string() == 'pkl/kelompok'
                            || uri_string() == 'pkl/jurnal/pelaksanaan'
                            || uri_string() == 'pkl/jurnal/bimbingan'
                            || uri_string() == 'pkl/jadwal'
                          ) ? 'active' : '' ?>">
        <a href="#">
          <i class="fa fa-book"></i>
          <span>PKL</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li class="<?= (uri_string() == 'pkl/kelompok') ? 'active' : '' ?>">
            <a href="<?= base_url('pkl/kelompok') ?>">
              <i class="fa fa-briefcase"></i> <span>Kelompok PKL</span>
            </a>
          </li>
          <li class="<?= (uri_string() == 'pkl/jurnal/pelaksanaan') ? 'active' : '' ?>">
            <a href="<?= base_url('pkl/jurnal/pelaksanaan') ?>">
              <i class="fa fa-briefcase"></i> <span>Jurnal Pelaksanaan</span>
            </a>
          </li>
          <li class="<?= (uri_string() == 'pkl/jurnal/bimbingan') ? 'active' : '' ?>">
            <a href="<?= base_url('pkl/jurnal/bimbingan') ?>">
              <i class="fa fa-briefcase"></i> <span>Jurnal Bimbingan</span>
            </a>
          </li>
          <li class="<?= (uri_string() == 'pkl/jadwal') ? 'active' : '' ?>">
            <a href="<?= base_url('pkl/jadwal') ?>">
              <i class="fa fa-calendar"></i> <span>Jadwal Sidang</span>
            </a>
          </li>
        </ul>
      </li>


      <li class="treeview">
        <a href="#">
          <i class="fa fa-book"></i>
          <span>KKN</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li class="<?= (uri_string() == 'pemasukan') ? 'active' : '' ?>">
            <a href="<?= base_url('pemasukan') ?>">
              <i class="fa fa-briefcase"></i> <span>Kelompok KKN</span>
            </a>
          </li>
          <li class="<?= (uri_string() == 'pengeluaran') ? 'active' : '' ?>">
            <a href="<?= base_url('pengeluaran') ?>">
              <i class="fa fa-briefcase"></i> <span>Jurnal Pelaksanaan</span>
            </a>
          </li>
          <li class="<?= (uri_string() == 'laporan') ? 'active' : '' ?>">
            <a href="<?= base_url('laporan') ?>">
              <i class="fa fa-briefcase"></i> <span>Jurnal Monitoring</span>
            </a>
          </li>
          <li class="<?= (uri_string() == 'laporan') ? 'active' : '' ?>">
            <a href="<?= base_url('laporan') ?>">
              <i class="fa fa-file-pdf-o"></i> <span>Laporan KKN</span>
            </a>
          </li>
        </ul>
      </li>

      <li class="treeview">
        <a href="#">
          <i class="fa fa-book"></i>
          <span>Skripsi</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li class="<?= (uri_string() == 'pemasukan') ? 'active' : '' ?>">
            <a href="<?= base_url('pemasukan') ?>">
              <i class="fa fa-briefcase"></i> <span>Jurnal Bimbingan</span>
            </a>
          </li>
          <li class="<?= (uri_string() == 'laporan') ? 'active' : '' ?>">
            <a href="<?= base_url('laporan') ?>">
              <i class="fa fa-calendar"></i> <span>Jadwal Sidang</span>
            </a>
          </li>
          <li class="<?= (uri_string() == 'laporan') ? 'active' : '' ?>">
            <a href="<?= base_url('laporan') ?>">
              <i class="fa fa-briefcase"></i> <span>Menentukan Dosbing</span>
            </a>
          </li>
        </ul>
      </li>

      <li class="<?= (uri_string() == 'tempat_sidang') ? 'active' : '' ?>">
        <a href="<?= base_url('tempat_sidang') ?>">
          <i class="fa fa-building-o"></i> <span>Tempat Sidang</span>
        </a>
      </li>
      <li class="<?= (uri_string() == 'akun') ? 'active' : '' ?>">
        <a href="<?= base_url('akun') ?>">
          <i class="fa fa-users"></i> <span>Daftar Akun</span>
        </a>
      </li>
      <li class="<?= (uri_string() == 'dosen_pembimbing') ? 'active' : '' ?>">
        <a href="<?= base_url('dosen_pembimbing') ?>">
          <i class="fa fa-users"></i> <span>Dosen Pembimbing</span>
        </a>
      </li>
      <li class="<?= (uri_string() == 'cetak-laporan') ? 'active' : '' ?>">
        <a href="<?= base_url('cetak-laporan') ?>">
          <i class="fa fa-file-pdf-o"></i> <span>Cetak Laporan</span>
        </a>
      </li>
    </ul>
  </section>
  <!-- /.sidebar -->
</aside>