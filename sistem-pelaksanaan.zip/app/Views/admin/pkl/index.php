<?= $this->extend('layouts/default'); ?>

<?= $this->section('content'); ?>

<!-- Default box -->
<?php if (session()->getFlashData('success') !== null) : ?>
  <div class="alert alert-success"><?= session()->getFlashData('success') ?></div>
<?php endif; ?>

<div class="box">
  <div class="box-header with-border">
    <h3 class="box-title">Kelompok PKL</h3>

    <div class="box-tools pull-right">
      <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
        <i class="fa fa-minus"></i></button>
      <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
        <i class="fa fa-times"></i></button>
    </div>
  </div>
  <div class="box-body">
    <button type="button" class="btn btn-primary mb-2" data-toggle="modal" data-target="#modal-tambah">
      Buat Kelompok
    </button>

    <div class="table-responsive">
      
    <table class="table table-hover" style="border: 1px solid #f0f0f0; margin-top: 10px;">
      <thead>
        <tr>
          <th>Kelompok</th>
          <th>Tahun Akademik</th>
          <th>Program Studi</th>
          <th>Dosen Pembimbing</th>
          <th>Ketua Kelompok</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($data as $row) : ?>
          <tr>
            <td><?= $row['nama_kelompok'] ?></td>
            <td><?= $row['tahun_akademik'] ?></td>
            <td><?= $row['nama_jurusan'] ?></td>
            <td><?= $row['nama_dosen'] ?></td>
            <td>
              <?php if ($row['ketua_kelompok']) : ?>
                <?= $row['ketua_kelompok'] ?>
              <?php else : ?>
                <span class="badge badge-warning">Belum ada ketua</span>
              <?php endif; ?>
            </td>
            <td class="text-center">
              <a href="<?= base_url('pkl/kelompok/edit_kelompok/' . $row['id']) ?>" class="btn btn-success btn-sm"><i class="fa fa-plus"></i></a>
              <a href="<?= base_url('pkl/kelompok/edit/' . $row['id']) ?>" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a>
              <form style="display: inline;" action="<?= base_url('pkl/kelompok/delete') ?>" method="POST">
                <input type="hidden" name="kelompok" value="<?= $row['id'] ?>">
                <button type="button" class="btn btn-danger btn-sm delete"><i class="fa fa-trash"></i></button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    </div>


  </div>
</div>
<!-- /.box -->

<div class="box">
  <div class="box-header with-border">
    <h3 class="box-title">Daftar Mahasiswa</h3>

    <div class="box-tools pull-right">
      <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
        <i class="fa fa-minus"></i></button>
      <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
        <i class="fa fa-times"></i></button>
    </div>
  </div>
  <div class="box-body">
    <table class="table table-hover" style="border: 1px solid #f0f0f0; margin-top: 10px;" id="mahasiswa">
      <thead>
        <tr>
          <th>No</th>
          <th>NIM</th>
          <th>Nama Mahasiswa</th>
          <th>Angkatan</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($data2 as $i => $row) : ?>
          <tr>
            <td><?= ++$i ?></td>
            <td><?= $row['nim'] ?></td>
            <td><?= $row['nama'] ?></td>
            <td><?= $row['angkatan'] ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<!-- /.box -->

<div class="modal fade" id="modal-tambah">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Buat Kelompok</h4>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?= base_url('pkl/kelompok') ?>">
          <div class="row" style="margin-bottom: 13px;">
            <div class="col-md-6">
              <label for="">Tanggal mulai</label>
              <input type="date" name="tgl_mulai" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="">Tanggal selesai</label>
              <input type="date" name="tgl_selesai" class="form-control">
            </div>
          </div>
          <div class="form-group">
            <label for="">Nama Kelompok</label>
            <input type="text" class="form-control" name="nama_kelompok">
          </div>
          <div class="form-group">
            <label for="">Prodi</label>
            <select name="prodi_id" class="form-control">
              <option value="">--- Pilih prodi ---</option>
              <?php foreach ($prodi as $row) : ?>
                <option value="<?= $row['id_jurusan'] ?>"><?= $row['nama_jurusan'] ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label for="">Dosen Pembimbing</label>
            <select name="dosen_id" class="form-control">
              <option value="">--- Pilih Dosen Pembimbing ---</option>
              <?php foreach ($dosen as $row) : ?>
                <option value="<?= $row['id'] ?>"><?= $row['nama'] ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label for="">Tahun Akademik</label>
            <select name="tahun_akademik" class="form-control">
              <option value="">--- Pilih Tahun Akademik ---</option>
              <option value="2020/2021">2020/2021</option>
              <option value="2021/2022">2021/2022</option>
              <option value="2022/2023">2022/2023</option>
              <option value="2023/2024">2023/2024</option>
            </select>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Tutup</button>
        <button type="submit" class="btn btn-primary pull-right">Simpan</button>
      </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>

<?= $this->endSection(); ?>

<?= $this->section('script'); ?>
<script src="<?= base_url('bower_components/datatables.net/js/jquery.dataTables.min.js') ?>"></script>
<script src="<?= base_url('bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js') ?>"></script>
<script>
  $(function() {
    // $('#example1').DataTable()
    $('#mahasiswa').DataTable({
      'paging': true,
      'lengthChange': true,
      'searching': false,
      'ordering': true,
      'info': true,
      'autoWidth': false
    })
  })

  $('.delete').click(function() {
    const ok = confirm('Yakin ingin menghapus kelompok?');

    if (ok) {
      $(this).parent().submit();
    }
  });
</script>
<?= $this->endSection(); ?>