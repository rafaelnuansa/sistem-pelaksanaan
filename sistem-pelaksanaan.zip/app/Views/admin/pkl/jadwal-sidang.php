<?= $this->extend('layouts/default'); ?>

<?= $this->section('content'); ?>

<!-- Default box -->
<?php if (session()->getFlashData('success') !== null) : ?>
  <div class="alert alert-success"><?= session()->getFlashData('success') ?></div>
<?php endif; ?>
<div class="box">
  <div class="box-header with-border">
    <h3 class="box-title">Jadwal Sidang</h3>

    <div class="box-tools pull-right">
      <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
        <i class="fa fa-minus"></i></button>
      <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
        <i class="fa fa-times"></i></button>
    </div>
  </div>
  <div class="box-body">
    <!-- <div class="py-2">
      <a href="<?= base_url('downloads/surat-tugas.pdf') ?>" class="btn btn-primary" target="_blank"><i class="fa fa-print" style="margin-right: 4px;"></i> Cetak Surat Tugas</a>
    </div> -->
    <div class="table-responsive">
      <table class="table table-hover" style="border: 1px solid #f0f0f0; margin-top: 10px;">
        <thead>
          <tr>
            <th>No</th>
            <th>NIM</th>
            <th>Nama mahasiswa</th>
            <th>Dosen pembimbing</th>
            <th>Dosen penguji</th>
            <th>Tempat</th>
            <th>Hari/Tanggal</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($data as $i => $row) : ?>
            <tr>
              <td><?= ++$i ?></td>
              <td><?= $row['nim'] ?></td>
              <td><?= $row['nama'] ?></td>
              <td><?= $row['dospem'] ?></td>
              <td><?= $row['dospeng'] ?></td>
              <td><?= $row['tempat'] ?></td>
              <td><?= $row['tanggal'] ?></td>
              <td>
              <td>
                <?php if (!$row['status']) : ?>
                  <a href="<?= base_url('pkl/jadwal/update_status/' . $row['id_jadwal_sidang'] . '/1') ?>" class="btn btn-warning" onclick="return confirm('Apakah Anda yakin ingin mengubah status menjadi Sudah Melaksanakan?')">Belum Melaksanakan</a>
                <?php else : ?>
                  <a href="<?= base_url('pkl/jadwal/update_status/' . $row['id_jadwal_sidang'] . '/0') ?>" class="btn btn-success" onclick="return confirm('Apakah Anda yakin ingin mengubah status menjadi Belum Melaksanakan?')">Sudah Melaksanakan</a>
                <?php endif; ?>
              </td>
              </td>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>

    </div>
  </div>
</div>


<?php if (session()->get('level') == 'Admin') : ?>
  <div class="box">
    <div class="box-header with-border">
      <h3 class="box-title">Menunggu Persetujuan</h3>

      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
          <i class="fa fa-minus"></i></button>
        <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
          <i class="fa fa-times"></i></button>
      </div>
    </div>
    <div class="box-body">
      <table class="table table-hover" style="border: 1px solid #f0f0f0; margin-top: 10px;">
        <thead>
          <tr>
            <th>No</th>
            <th>Nama mahasiswa</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($pending as $i => $row) : ?>
            <tr>
              <td><?= ++$i ?></td>
              <td><?= $row['nama'] ?></td>
              <td class="text-center">
                <button class="btn btn-success approve btn-sm" data-id="<?= $row['id_ujian_pkl'] ?>" data-user-id="<?= $row['user_id'] ?>"><i class="fa fa-check"></i></button>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <!-- /.box -->

  <div class="modal fade" id="modal-approve">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Tambahkan Jadwal</h4>
        </div>
        <div class="modal-body">
          <form method="POST" action="<?= base_url('pkl/jadwal/simpan') ?>">
            <input type="hidden" name="id_daftar">
            <input type="hidden" name="user_id">
            <div class="row mb-2">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="">Hari / Tanggal</label>
                  <input type="date" class="form-control" name="tanggal">
                </div>
              </div>
            </div>
            <div class="row mb-2">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="">Nama mahasiswa</label>
                  <input type="text" class="form-control" name="nama">
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="">NIM</label>
                  <input type="text" class="form-control" name="nim">
                </div>
              </div>
            </div>
            <div class="row mb-2">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="">Dosen Pembimbing</label>
                  <input type="text" class="form-control" name="dospem">
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="">Dosen Penguji</label>
                  <input type="text" class="form-control" name="dospeng">
                </div>
              </div>
            </div>
            <div class="row mb-2">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="">Tempat</label>
                  <input type="text" class="form-control" name="tempat">
                </div>
              </div>
            </div>
            <div class="row mb-2">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="">Keterangan</label>
                  <textarea name="keterangan" rows="4" class="form-control"></textarea>
                </div>
              </div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-primary">Simpan & Setujui</button>
        </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>

<?php endif; ?>

<?= $this->endSection(); ?>

<?= $this->section('script'); ?>
<script>
  $('.approve').click(function() {
    $('#modal-approve [name="id_daftar"]').val($(this).attr('data-id'));
    $('#modal-approve [name="user_id"]').val($(this).attr('data-user-id'));
    $('#modal-approve').modal('show');
  });

  $('.edit').click(function() {
    const id = $(this).attr('data-id');
    $.get('<?= base_url('pkl/kelompok/show?id=') ?>' + id, function(data) {
      $('#modal-edit [name="id"]').val(id);
      $('#modal-edit [name="nama_mhs"]').val(data.nama_mhs);
      $('#modal-edit [name="nim"]').val(data.nim);
      $('#modal-edit [name="kelompok"]').val(data.kelompok);

      $('#modal-edit [name="id_jurusan"] option').each(function() {
        if (this.text == data.nama_jurusan) {
          this.setAttribute('selected', '');
        }
      });

      $('#modal-edit [name="status"] option').each(function() {
        if (this.text == data.status) {
          this.setAttribute('selected', '');
        }
      });
    })
    $('#modal-edit').modal('show');
  });

  $('.detail').click(function() {
    const id = $(this).attr('data-id');
    $.get('<?= base_url('pkl/jadwal/detail?id=') ?>' + id, function(data) {
      $('#modal-detail [name="nama"]').val(data.nama);
      $('#modal-detail [name="nim"]').val(data.nim);
      $('#modal-detail [name="tempat_pkl"]').val(data.tempat_pkl);
      $('#modal-detail [name="dospem"]').val(data.dospem);
      $('#modal-detail [name="judul_laporan"]').val(data.judul_laporan);

      $('#modal-detail [name="id_jurusan"] option').each(function() {
        if (this.text == data.nama_jurusan) {
          this.setAttribute('selected', '');
        }
      });
    });

    $('#modal-detail').modal('show');
  });
</script>
<?= $this->endSection(); ?>