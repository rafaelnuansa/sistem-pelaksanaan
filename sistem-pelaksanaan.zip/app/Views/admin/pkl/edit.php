<?= $this->extend('layouts/default'); ?>

<?= $this->section('content'); ?>

<!-- Default box -->
<?php if (session()->getFlashData('success') !== null) : ?>
    <div class="alert alert-success"><?= session()->getFlashData('success') ?></div>
<?php endif; ?>
<div class="box">
    <div class="box-header with-border">
        <h3 class="box-title"><?= $title ?></h3>
        <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                <i class="fa fa-times"></i></button>
        </div>
    </div>
    <div class="box-body"> 
        <form method="POST" action="<?= base_url('pkl/kelompok/update_data') ?>">
          <input type="hidden" name="id" value="<?= $data['id'];?>">
            <div class="row" style="margin-bottom: 13px;">
                <div class="col-md-6">
                    <label for="">Tanggal mulai</label>
                    <input type="date" name="tgl_mulai" value="<?= $data['tgl_mulai']; ?>" class="form-control">
                </div>
                <div class="col-md-6">
                    <label for="">Tanggal selesai</label>
                    <input type="date" name="tgl_selesai" value="<?= $data['tgl_selesai']; ?>" class="form-control">
                </div>
            </div>
            <div class="form-group">
                <label for="">Nama Kelompok</label>
                <input type="text" class="form-control" name="nama_kelompok" value="<?= $data['nama_kelompok']; ?>">
            </div>
            <div class="form-group">
                <label for="">Prodi</label>
                <select name="prodi_id" class="form-control">
                    <option value="">--- Pilih prodi ---</option>
                    <?php foreach ($prodi as $row) : ?>
                        <?php if ($row['id_jurusan'] == $data['prodi_id']) : ?>
                            <option value="<?= $row['id_jurusan'] ?>" selected><?= $row['nama_jurusan'] ?></option>
                        <?php else : ?>
                            <option value="<?= $row['id_jurusan'] ?>"><?= $row['nama_jurusan'] ?></option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>

            </div>
            <div class="form-group">
                <label for="">Dosen Pembimbing</label>
                <select name="dosen_id" class="form-control">
                    <option value="">--- Pilih Dosen Pembimbing ---</option>
                    <?php foreach ($dosen as $row) : ?>
                        <?php if ($row['id_dosen'] == $data['dosen_id']) : ?>
                            <option value="<?= $row['id_dosen'] ?>" selected><?= $row['nama_dosen'] ?></option>
                        <?php else : ?>
                            <option value="<?= $row['id_dosen'] ?>"><?= $row['nama_dosen'] ?></option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>

            </div>
            <div class="form-group">
                <label for="">Tahun Akademik</label>
                <select name="tahun_akademik" class="form-control">
                    <option value="">-- Pilih Tahun --</option>
                    <option value="2020/2021" <?= ($tahun_akademik == '2020/2021') ? ' selected' : '' ?>>2020/2021</option>
                    <option value="2021/2022" <?= ($tahun_akademik == '2021/2022') ? ' selected' : '' ?>>2021/2022</option>
                    <option value="2022/2023" <?= ($tahun_akademik == '2022/2023') ? ' selected' : '' ?>>2022/2023</option>
                    <option value="2023/2024" <?= ($tahun_akademik == '2023/2024') ? ' selected' : '' ?>>2023/2024</option>
                </select>

            </div>
            <div class="form-group">

                <button type="submit" class="btn btn-primary pull-right">Simpan</button>
            </div>
        </form>
    </div>
</div>
<!-- /.box -->
<?= $this->endSection(); ?>